# TeamFrame Product & Implementation Overview — Pending Register

Internal document. Everything below is required before an external prospect build.

Status: **CONTENT & DESIGN FROZEN — screenshots/contact/commercial fields only pending**

---

## 1. Screenshot placeholder register

All four placements are designed as finished compositions. Dropping the final
crop in requires no layout change.

### Placeholder 01 — Documents: expiry & evidence (primary)
- **Where:** Chapter III (screen) and print page 04
- **Route/screen:** Documents / requirements view
- **Crop ratio:** 16:10
- **Capture viewport:** 1440 wide, standard density
- **Must demonstrate:** a document expiring soon, and a requirement that cannot
  be marked complete without the evidence being uploaded. Proves the
  evidence-gated closure and expiry-monitoring differentiators.
- **Notes:** this is the single most important image in the document. Use a
  seeded demo tenant with realistic dates. No empty state.

### Placeholder 02 — Access: salary & private hidden
- **Where:** Chapter V (screen) and print page 06
- **Route/screen:** Access settings for a non-full-access profile
- **Crop ratio:** 16:9 (screen placement in Chapter V). Print page 06 uses a
  tighter horizontal strip crop.
- **Capture viewport:** 1440 wide
- **Must demonstrate:** a People Operations administrator with people, leave and
  documents granted, and Salary + private files set to hidden — proving the
  confidential-access differentiator.
- **Notes:** use realistic names on a seeded demo tenant; do not mix real and
  dummy data.

### Placeholder 03 — Org chart or employee self-service
- **Where:** Chapter II (screen) and available for print page 03 if wanted
- **Route/screen:** Org chart **or** employee self-service — either fits
- **Crop ratio:** 16:10
- **Capture viewport:** 1440 wide
- **Must demonstrate:** reporting structure, or the employee's own view of their
  record. One strong complementary surface only.

### Placeholder 04 — Employee record
- **Where:** Chapter IV (screen) and print page 05
- **Route/screen:** Employee record / profile
- **Crop ratio:** 4:3
- **Capture viewport:** 1440 wide
- **Must demonstrate:** employment details, lifecycle history and connected HR
  information visible on one record — that TeamFrame is an operating system,
  not a reminder dashboard.
- **Notes:** a record with real history (a role change, a leave entry, a signed
  document) is far stronger than a freshly created one.

### Treatment rules when the real images arrive
- Tight crops of the interface itself. No laptop, phone, browser chrome or
  perspective mockups.
- Keep the corner-bracket framing already in place; the crop sits inside it.
- Anonymise names/emails consistently — do not mix real and dummy data.

---

## 2. Contact and commercial placeholder register

All of these are **editable fields on the design** (Tweaks → "Commercial —
pending"). None are hard-coded. While `showInternal` is on, unset fields render
as a labelled `INTERNAL · PENDING` block rather than a blank line.

| Field | Status | Blocking external release? |
| --- | --- | --- |
| `contactName` | Not set | Yes |
| `contactEmail` | Not set — commercial email not frozen | Yes |
| `contactWebsite` | Not set | Yes |
| `contactPhone` | Not set — optional | No |
| `contactEntity` | Not set — contracting entity undecided | Yes |
| `ctaHref` | Not set — CTA currently scrolls to Chapter IX | Yes |
| `canonicalUrl` | Not set — Share falls back to current URL | Yes |
| `preparedFor` | Set per prospect | No (per-send) |

### Release procedure
1. Populate the fields above.
2. Set `showInternal` to **off** — this removes every INTERNAL · PENDING marker.
   Any field still empty is then hidden entirely rather than shown blank.
3. Replace the four screenshot placeholders.
4. Host the file and set `canonicalUrl` so Share produces a usable link.

---

## 3. Commercial model items — APPROVED

Approved and now built into the overview (Chapter VII — Choose how you want to
operate):

- **TeamFrame** — customer-operated model. The complete product, implemented and
  handed over for the customer's team to operate.
- **TeamFrame + People Ops** — supported operating model. Same environment, same
  implementation, plus agreed ongoing People Operations support.
- **Full-Cycle Recruitment** — optional, separately scoped service.
- Recruitment sits **outside** the TeamFrame software. No ATS, pipeline,
  candidate database or recruitment UI anywhere in the product story.
- Recruitment can accompany **either** core operating model, and is not implied
  to be included in either.

Chapter architecture is now I–X; Chapter VII is the new commercial chapter and
print is 11 pages (cover + I–X).

---

## 3a. Commercial messaging update — Aug 2026

Content-only pass over the approved design (no visual/layout redesign):

- **Segment openings.** Chapter I headline + four problem blocks are now driven
  by a `segment` Tweak (Personalisation): Neutral / UAE / Mauritius / Startup.
  One master; the reader only ever sees their own opening. Shared chapters
  (II–X) are identical across segments.
- **Chapter III** reframed from "Signal → Action → Resolution" to the five
  differentiators (evidence-gated closure, expiry monitoring, versioned policy
  acknowledgement, confidential access, work appears automatically). The policy
  worked-example is retained as live proof.
- **Payroll boundary** stated plainly in Chapter IX: works alongside the
  existing payroll provider/PRO/accountant; does not run payroll or generate
  WPS/SIF; maintains employment facts and a structured handover.
- **CTA** is now "Book a TeamFrame walkthrough" everywhere.
- **Positioning** broadened off fixed 5–25 startups to "organisations where HR
  admin is real work but there is no dedicated HR team" (~10–70 people).
- **Credential line** kept neutral — no unverified practitioner claims.

---

## 4. Pending commercial freeze

None of the following may be invented in the prospect overview. They belong in
the separate customer-specific commercial proposal.

### TeamFrame + People Ops
- detailed service inclusions
- detailed exclusions
- service availability / hours
- support channels
- response expectations
- commercial fee
- billing structure
- minimum term, if any

### Full-Cycle Recruitment
- exact recruitment process
- geography
- sourcing channels
- client responsibilities
- candidate assessment process
- reference-check scope
- recruitment fee structure
- payment trigger
- replacement terms, if any
- exclusivity, if any
- assignment validity / timeframe

---

## 5. Known limits of this build

- **Fonts are loaded from Google Fonts.** True self-hosting needs the Mulish and
  IBM Plex Mono files supplied; until then a system fallback stack renders if
  the font service is blocked. This is a deployment step, not a design one.
- **Share is not hosted.** Until `canonicalUrl` is set, Share copies the local
  URL. Chapter deep-linking and the clipboard fallback are already built.
- **No commercial terms.** No price, licence period, validity or scope. This
  document is deliberately an overview; a separate commercial proposal should
  carry those.

---

## 6. Deliberate omissions

Not present, and should stay absent until real: pricing, customer logos,
testimonials, customer counts, ROI or time-saving statistics, integrations,
certifications, compliance claims, guarantees.

Also deliberately absent: any additional service category beyond Full-Cycle
Recruitment (no HR/compensation/policy consulting, payroll outsourcing, employee
relations, training, performance, compliance advisory, immigration, benefits or
HR strategy). Add only when commercially defined.
